
# Full Stack Capstone Project

Casting Agency App:

It is a company that is responsible for creating movies and managing and assigning actors to those movies, through this app.


# The URL for the application which hosted on Heroku:

https://capstone-yusra.herokuapp.com/ 

# Installing Dependencies

pip install -r requirements.txt

This will install all of the required packages we selected within the `requirements.txt` file.


# Explaining the job of each file in this folder project:

1- app.py:
Has all the endpoints/requests we have for our app.

2- auth.py:
Has the authinitacation codes.

3- manage.py:
Managing the app, and containe the migration part.

4- models.py:
Has the models for our app.

5- test_app.py:
Contains the unittest for our endpoints to test their success and their failed + testing the endpoints authentication validity.

6- setup.sh:
Contains all the defined variables for our .py files. 






# To run the app (app.py) locally:

1- create a db called (project5).
2- Uncomment the first line in setup.sh
3- Comment the second line in setup.sh
4- run:
source setup.sh

5- run: 
export FLASK_APP=app
export FLASK_ENV=development
flask run


# To run the test we made for our app through (test_app.py) locally:

1- create a db called (project5test),and insert data to the it.
2- run:
source setup.sh
3- run:
python3 test_app.py




# App documintation:

Endpoints:

GET '/movies'
GET '/actors'
POST '/movies/new'
POST '/actors/new'
DELETE '/movies/<int:movie_id>'
DELETE '/actors/<int:actor_id>'
PATCH '/movies/<int:movie_id>'
PATCH '/actors/<int:actor_id>'



GET '/movies'
- Get a list of all the movies.
- Request Arguments: None
- Returns: A list of movies, each movie with it's title and the release_date of it.
{'title' : 'titanic',
'release_date' : '2012-08-15'}


GET '/movies'
- Get a list of all the actors.
- Request Arguments: None
- Returns: A list of actors, each actor with it's name, age and gender.
{'name' : 'Michal',
'age' : '30',
'gender': 'male'}




POST '/movies/new'

-This endpoint where the user could post/create new movie with its: title/release_date .

- Request Arguments: 2 requested arguments which are:
1- title.
2- release_date.


- Returns: 

The title for the new movie created. 

{
	"created_movie" : 'passengers',
	"success" : true
}


POST '/actors/new'

-This endpoint where the user could post/create new actor with its: name/ age/ gender .

- Request Arguments: 3 requested arguments which are:
1- name.
2- age.
3- gender.


- Returns: 

The name for the new actor created. 

{
	"created_actor" : 'Anna',
	"success" : true
}



DELETE '/movies/<int:movie_id>'

This endpoint will delete a movie posted.

- Request Argument: None. 

- Returns:

If the movie does exist and was deleted:

{
	"success" : true
	"deleted_movie_title" : 'passenger',
	
}

If the movie.id wasn't exist:

{
  "error": 404, 
  "message": "recource not found", 
  "success": false
}



DELETE '/actors/<int:actor_id>'

This endpoint will delete a actor posted.

- Request Argument: None. 

- Returns:

If the actor does exist and was deleted:

{
	"success" : true
	"deleted_actor_name" : 'Anna',
	
}

If the actor.id wasn't exist:

{
  "error": 404, 
  "message": "recource not found", 
  "success": false
}



PATCH '/movies/<int:movie_id>'

This endpoint will update the release_date for a movie posted.

- Request Argument: 1 requested argument which is:
1- the new release_date.

- Returns:

If the movie.id does exist and was updated:

{
	"success" : true,
	"movie_title" : 'titanic'
	"new_release_date" : '2020-06-19',
	
}

If the movie.id wasn't exist:

{
  "error": 404, 
  "message": "recource not found", 
  "success": false
}



PATCH '/actors/<int:actor_id>'

This endpoint will update the age for a actor posted.

- Request Argument: 1 requested argument which is:
1- the new age.

- Returns:

If the actor.id does exist and was updated:

{
	"success" : true,
	"actor_name" : 'Anna'
	"actor_updated_age" : '35',
	
}

If the actor.id wasn't exist:

{
  "error": 404, 
  "message": "recource not found", 
  "success": false
}






# Roles and their Permissions:

- Assistatnt:
Can:

GET '/movies'
GET '/actors'


- Director:
Can:

GET '/movies'
GET '/actors'
POST '/actors/new'
DELETE '/actors/<int:actor_id>'
PATCH '/movies/<int:movie_id>'
PATCH '/actors/<int:actor_id>'


- Producer:
Can:

GET '/movies'
GET '/actors'
POST '/movies/new'
POST '/actors/new'
DELETE '/movies/<int:movie_id>'
DELETE '/actors/<int:actor_id>'
PATCH '/movies/<int:movie_id>'
PATCH '/actors/<int:actor_id>'
