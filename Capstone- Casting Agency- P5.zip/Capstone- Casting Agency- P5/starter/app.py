import os
from flask import Flask, request, abort, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from models import setup_db, movies, actors

from auth import AuthError, requires_auth

def create_app(test_config=None):
  # create and configure the app
  app = Flask(__name__)
  setup_db(app)
  CORS(app)



  @app.route('/welcome')

  def home_page():
    
    return "Welcome to Casting Agency App"


  
  
  @app.route('/movies')
  @requires_auth('get:movies')
  
  def get_movies(jwt):
  


    data = []
    movies_list = movies.query.all()
    

    for movie in movies_list:
      data.append({"title" : movie.title, "release_date" : movie.release_date})
    

    return jsonify ({
      'success': True,
      'movies_list' : data
    })


  @app.route('/actors')
  @requires_auth('get:actors')
  def get_actors(jwt):


    data = []
    actors_list = actors.query.all()
    

    for actor in actors_list:
      data.append({"name" : actor.name, "age" : actor.age, "gender" : actor.gender})
    

    return jsonify ({
      'success': True,
      'actors_list' : data
    })

  
  @app.route('/movies/<int:movie_id>', methods= ['DELETE'])
  @requires_auth('delete:movies')
  def delete_movie(jwt, movie_id):

    try:
      movie = movies.query.filter(movies.id == movie_id).one_or_none()
        
      movie.delete()
      
      return jsonify({
        'success' : True,
        'deleted_movie_title' : movie.title
      })

    except: 
      abort(404)


  @app.route('/actors/<int:actor_id>', methods= ['DELETE'])
  @requires_auth('delete:actors')
  def delete_actor(jwt, actor_id):

    try:
      actor = actors.query.filter(actors.id == actor_id).one_or_none()
              
      actor.delete()
      
      return jsonify({
        'success' : True,
        'deleted_actor_name' : actor.name
      })

    except: 
      abort(404)




  @app.route('/movies/new', methods=['POST'])
  @requires_auth('post:movies')
  def create_new_movie(jwt):
    
    define_get = request.get_json()
    new_movie = movies(
      title= request.json.get('title'),
      release_date= request.json.get('release_date')
    )


    new_movie.insert()
    return jsonify({
      'success': True,
      'created_movie' : new_movie.title
      })



  @app.route('/actors/new', methods=['POST'])
  @requires_auth('post:actors')
  def create_new_actor(jwt):
    
    define_get = request.get_json()
    new_actor = actors(
      name= request.json.get('name'),
      age= request.json.get('age'),
      gender= request.json.get('gender')
    )


    new_actor.insert()
    return jsonify({
      'success': True,
      'created_actor' : new_actor.name
      })





  @app.route('/movies/<int:movies_id>', methods= ['PATCH'])
  @requires_auth('patch:movies')
  def update_movies(jwt, movies_id):

    define_get = request.get_json()
    
    
    try:
        movie = movies.query.filter(movies.id == movies_id).one_or_none()

        if 'id' in define_get:
          movie.id= int(define_get.get('id'))


        if 'release_date' in define_get:
          movie.release_date= format(define_get.get('release_date'))

        
        
        movie.update()
        return jsonify({
            'success': True,
            'movie_title' : movie.title,
            'new_release_date' : movie.release_date
        })

    except:
        abort(404)


  @app.route('/actors/<int:actors_id>', methods= ['PATCH'])
  @requires_auth('patch:actors')
  def update_actors(jwt, actors_id):

    define_get = request.get_json()
    
    
    try:
        actor = actors.query.filter(actors.id == actors_id).one_or_none()

        if 'id' in define_get:
          actor.id= int(define_get.get('id'))


        if 'age' in define_get:
          actor.age= str(define_get.get('age'))

        
        
        actor.update()
        return jsonify({
            'success': True,
            'actor_name' : actor.name,
            'actor_updated_age' : actor.age
        })

    except:
        abort(404)








  
 # Error Handling:
  
  @app.errorhandler(400)
  def bad_request_error(error):
    return jsonify({
      "success" : False,
      "error" : 400,
      "message" : "request format was wrong"
    }), 400

  @app.errorhandler(422)
  def unprocessable_error(error):
    return jsonify({
      "success" : False,
      "error" : 422,
      "message" : "unprocessable"
    }), 422

  @app.errorhandler(404)
  def not_found_error(error):
    return jsonify({
      "success" : False,
      "error" : 404,
      "message" : "recource not found"
    }), 404
    
    

# Error handler for AuthError:


  
  @app.errorhandler(AuthError)
  def handle_auth_error(ex):
    response = jsonify(ex.error)
    response.status_code = ex.status_code
    return response
  




  return app

APP = create_app()

if __name__ == '__main__':
    APP.run(host='0.0.0.0', port=8080, debug=True)

