import os
import unittest
import json
from flask_sqlalchemy import SQLAlchemy
from models import setup_db, movies, actors
from app import create_app



DIRECTOR = os.environ.get('DIRECTOR')
ASSISTANT = os.environ.get('ASSISTANT')
PRODUCER = os.environ.get('PRODUCER')


# This class represents the Capstone Test Case
class CapstoneTestCase(unittest.TestCase):
	

# Here we will Define test variables and initialize app.	
	def setUp(self):
		self.app = create_app()
		self.client = self.app.test_client
		self.database_path = os.environ.get('DATABASE_TEST_URL')
		setup_db(self.app, self.database_path)
		

# Now we will binds the app to the current context		
		with self.app.app_context():
			self.db = SQLAlchemy()
			self.db.init_app(self.app)
			self.db.create_all()


	def tearDown(self):

		pass
	

# Now we will test each endpoint we have + with it's role auth:


	def test_get_movies(self):
		res = self.client().get('/movies', headers= dict(Authorization= f'bearer {ASSISTANT}'))
		data = json.loads(res.data)
		
		self.assertEqual(res.status_code, 200)
		self.assertEqual(data['success'], True)
		self.assertTrue(data['movies_list'])


	
	def test_get_actors(self):
		res = self.client().get('/actors', headers= dict(Authorization= f'bearer {ASSISTANT}'))
		data = json.loads(res.data)
		
		self.assertEqual(res.status_code, 200)
		self.assertEqual(data['success'], True)
		self.assertTrue(data['actors_list'])

	       

	def test_create_new_movie(self):
		res = self.client().post('/movies/new', json= dict(title= 'test auth', release_date= '2020-12-20' ), headers= dict(Authorization= f'bearer {PRODUCER}'))
		data = json.loads(res.data)
		
		self.assertEqual(res.status_code, 200)
		self.assertEqual(data['success'], True)
		self.assertTrue(data['created_movie'])
		
		
	def test_create_new_actor(self):

		res = self.client().post('/actors/new', json= dict(name= 'ysooor2', age= '25',gender= 'female' ), headers= dict(Authorization= f'bearer {DIRECTOR}'))
		data = json.loads(res.data)
		
		self.assertEqual(res.status_code, 200)
		self.assertEqual(data['success'], True)
		self.assertTrue(data['created_actor'])

# This endpoint is working successfuly, I commented to stop deleting the record:		
	'''
	def test_delete_movie(self):
		res = self.client().delete('/movies/11', headers= dict(Authorization= f'bearer {PRODUCER}'))
		data = json.loads(res.data)


		self.assertEqual(res.status_code, 200)
		self.assertEqual(data['success'], True)
	'''


	def test_404_if_movie_not_exist(self):
		res = self.client().delete('/movies/11', headers= dict(Authorization= f'bearer {PRODUCER}'))
		data = json.loads(res.data)


		self.assertEqual(res.status_code, 404)
		self.assertEqual(data['success'], False)
		self.assertEqual(data['message'], 'recource not found')


# This endpoint is working successfuly, I commented to stop deleting the record:
	'''
	def test_delete_actor(self):
		res = self.client().delete('/actors/3', headers= dict(Authorization= f'bearer {DIRECTOR}'))
		data = json.loads(res.data)


		self.assertEqual(res.status_code, 200)
		self.assertEqual(data['success'], True)
	'''

	def test_404_if_actor_not_exist(self):
		res = self.client().delete('/actors/9', headers= dict(Authorization= f'bearer {DIRECTOR}'))
		data = json.loads(res.data)


		self.assertEqual(res.status_code, 404)
		self.assertEqual(data['success'], False)
		self.assertEqual(data['message'], 'recource not found')


	
	def test_update_movie(self):
		res = self.client().patch('/movies/12', json= dict(release_date = '2040-09-12'), headers= dict(Authorization= f'bearer {DIRECTOR}'))
		data = json.loads(res.data)

		movie = movies.query.filter(movies.id == 12).one_or_none()

		self.assertEqual(res.status_code, 200)
		self.assertEqual(data['success'], True)
	
	
	def test_404_if_movie_id_not_exist(self):
		
		res = self.client().patch('/movies/11', json= dict(release_date = '2040-09-12'), headers= dict(Authorization= f'bearer {DIRECTOR}'))
		data = json.loads(res.data)


		self.assertEqual(res.status_code, 404)
		self.assertEqual(data['success'], False)
		self.assertEqual(data['message'], 'recource not found')	


	
	
	def test_update_actor(self):
		
		res = self.client().patch('/actors/2', json= dict(age= '88'), headers= dict(Authorization= f'bearer {DIRECTOR}'))
		data = json.loads(res.data)

		actor = actors.query.filter(actors.id == 2).one_or_none()

		self.assertEqual(res.status_code, 200)
		self.assertEqual(data['success'], True)
	
	
	def test_404_if_actor_id_not_exist(self):
		res = self.client().patch('/actors/9', json= dict(age= '80'), headers= dict(Authorization= f'bearer {DIRECTOR}'))
		data = json.loads(res.data)


		self.assertEqual(res.status_code, 404)
		self.assertEqual(data['success'], False)
		self.assertEqual(data['message'], 'recource not found')	


#-------------------------------------------------------------------
# Test role accessibility failed:
#-------------------------------------------------------------------

# Test if (Assistant) won't be able to patch an actor:
	def test_assistant_update_actor(self):
		
		res = self.client().patch('/actors/2', json= dict(age= '88'), headers= dict(Authorization= f'bearer {ASSISTANT}'))
		data = json.loads(res.data)

		actor = actors.query.filter(actors.id == 2).one_or_none()

		self.assertEqual(res.status_code, 401)

# Test if (Director) won't be able to post a movie:	
		
	def test_director_create_new_movie(self):
		res = self.client().post('/movies/new', json= dict(title= 'test auth', release_date= '2020-12-20' ), headers= dict(Authorization= f'bearer {DIRECTOR}'))
		data = json.loads(res.data)
		
		self.assertEqual(res.status_code, 401)


# Since the (Producer) has an access for every endpoint, so we don't need to test his accessibility failed. Because nothing will failed #

	





if __name__ == "__main__":
	unittest.main()

